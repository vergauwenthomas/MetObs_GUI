[![Local Installation testing](https://github.com/vergauwenthomas/MetObs_GUI/actions/workflows/os_istall_test.yml/badge.svg)](https://github.com/vergauwenthomas/MetObs_GUI/actions/workflows/os_istall_test.yml)
[![.github/workflows/os_pip_install_test.yml](https://github.com/vergauwenthomas/MetObs_GUI/actions/workflows/os_pip_install_test.yml/badge.svg)](https://github.com/vergauwenthomas/MetObs_GUI/actions/workflows/os_pip_install_test.yml)


# MetObs_GUI
A Graphical interface of the MetObs_toolkit

# Install
Unstable: 
`pip install git+https://github.com/vergauwenthomas/MetObs_GUI.git`

Prerelease:
`pip install MetObs-GUI --pre`

# Usage
In python:

```
import metobs_gui 
metobs_gui.launch_gui()
```
