# MetObs_GUI
A Graphical interface of the MetObs_toolkit

# Install

`pip install git+https://github.com/vergauwenthomas/MetObs_GUI.git`

# Usage
In python:

```
import metobs_gui 
metobs_gui.launch_gui()
```
